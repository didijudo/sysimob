--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = perfil, pg_catalog;

ALTER TABLE ONLY perfil.tb_perfil_trans DROP CONSTRAINT tb_trans_tb_perfil_trans_fk;
ALTER TABLE ONLY perfil.tb_usuario DROP CONSTRAINT tb_perfil_tb_usuario_fk;
ALTER TABLE ONLY perfil.tb_perfil_trans DROP CONSTRAINT tb_perfil_tb_perfil_trans_fk;
ALTER TABLE ONLY perfil.tb_usuario DROP CONSTRAINT usuario_pk;
ALTER TABLE ONLY perfil.tb_trans DROP CONSTRAINT trans_pk;
ALTER TABLE ONLY perfil.tb_perfil_trans DROP CONSTRAINT perfil_trans_pk;
ALTER TABLE ONLY perfil.tb_perfil DROP CONSTRAINT perfil_pk;
ALTER TABLE perfil.tb_trans ALTER COLUMN cdtrans DROP DEFAULT;
ALTER TABLE perfil.tb_perfil ALTER COLUMN cdperfil DROP DEFAULT;
DROP TABLE perfil.tb_usuario;
DROP SEQUENCE perfil.tb_trans_cdtrans_seq;
DROP TABLE perfil.tb_trans;
DROP TABLE perfil.tb_perfil_trans;
DROP SEQUENCE perfil.cdperfil_seq;
DROP TABLE perfil.tb_perfil;
DROP PROCEDURAL LANGUAGE plpgsql;
DROP SCHEMA public;
DROP SCHEMA perfil;
--
-- Name: SysImob; Type: COMMENT; Schema: -; Owner: admin
--

COMMENT ON DATABASE "SysImob" IS 'DB System Imobiliario.';


--
-- Name: perfil; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA perfil;


ALTER SCHEMA perfil OWNER TO postgres;

--
-- Name: SCHEMA perfil; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA perfil IS 'Schema para controle dos dados de perfil e usuario';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: postgres
--

CREATE OR REPLACE PROCEDURAL LANGUAGE plpgsql;


ALTER PROCEDURAL LANGUAGE plpgsql OWNER TO postgres;

SET search_path = perfil, pg_catalog;

SET default_tablespace = ts_pefil;

SET default_with_oids = false;

--
-- Name: tb_perfil; Type: TABLE; Schema: perfil; Owner: admin; Tablespace: ts_pefil
--

CREATE TABLE tb_perfil (
    cdperfil integer NOT NULL,
    dsperfil character varying(100) NOT NULL,
    flativo character(1) NOT NULL
);


ALTER TABLE perfil.tb_perfil OWNER TO admin;

--
-- Name: cdperfil_seq; Type: SEQUENCE; Schema: perfil; Owner: admin
--

CREATE SEQUENCE cdperfil_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE perfil.cdperfil_seq OWNER TO admin;

--
-- Name: cdperfil_seq; Type: SEQUENCE OWNED BY; Schema: perfil; Owner: admin
--

ALTER SEQUENCE cdperfil_seq OWNED BY tb_perfil.cdperfil;


--
-- Name: cdperfil_seq; Type: SEQUENCE SET; Schema: perfil; Owner: admin
--

SELECT pg_catalog.setval('cdperfil_seq', 2, true);


--
-- Name: tb_perfil_trans; Type: TABLE; Schema: perfil; Owner: admin; Tablespace: ts_pefil
--

CREATE TABLE tb_perfil_trans (
    cdperfil integer NOT NULL,
    cdtrans integer NOT NULL,
    flinserir character(1) NOT NULL,
    flalterar character(1) NOT NULL,
    flexcluir character(1) NOT NULL,
    flconsultar character(1) NOT NULL
);


ALTER TABLE perfil.tb_perfil_trans OWNER TO admin;

--
-- Name: tb_trans; Type: TABLE; Schema: perfil; Owner: admin; Tablespace: ts_pefil
--

CREATE TABLE tb_trans (
    cdtrans integer NOT NULL,
    dstrans character varying(100) NOT NULL,
    flativa character(1) NOT NULL
);


ALTER TABLE perfil.tb_trans OWNER TO admin;

--
-- Name: tb_trans_cdtrans_seq; Type: SEQUENCE; Schema: perfil; Owner: admin
--

CREATE SEQUENCE tb_trans_cdtrans_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE perfil.tb_trans_cdtrans_seq OWNER TO admin;

--
-- Name: tb_trans_cdtrans_seq; Type: SEQUENCE OWNED BY; Schema: perfil; Owner: admin
--

ALTER SEQUENCE tb_trans_cdtrans_seq OWNED BY tb_trans.cdtrans;


--
-- Name: tb_trans_cdtrans_seq; Type: SEQUENCE SET; Schema: perfil; Owner: admin
--

SELECT pg_catalog.setval('tb_trans_cdtrans_seq', 2, true);


--
-- Name: tb_usuario; Type: TABLE; Schema: perfil; Owner: admin; Tablespace: ts_pefil
--

CREATE TABLE tb_usuario (
    cpfusuario character(11) NOT NULL,
    cdperfil integer NOT NULL,
    nmusuario character varying(50) NOT NULL,
    pwdusuario character varying(100) NOT NULL,
    flativo character(1) NOT NULL
);


ALTER TABLE perfil.tb_usuario OWNER TO admin;

--
-- Name: cdperfil; Type: DEFAULT; Schema: perfil; Owner: admin
--

ALTER TABLE ONLY tb_perfil ALTER COLUMN cdperfil SET DEFAULT nextval('cdperfil_seq'::regclass);


--
-- Name: cdtrans; Type: DEFAULT; Schema: perfil; Owner: admin
--

ALTER TABLE ONLY tb_trans ALTER COLUMN cdtrans SET DEFAULT nextval('tb_trans_cdtrans_seq'::regclass);


--
-- Data for Name: tb_perfil; Type: TABLE DATA; Schema: perfil; Owner: admin
--

COPY tb_perfil (cdperfil, dsperfil, flativo) FROM stdin;
2	Perfil Master	1
\.


--
-- Data for Name: tb_perfil_trans; Type: TABLE DATA; Schema: perfil; Owner: admin
--

COPY tb_perfil_trans (cdperfil, cdtrans, flinserir, flalterar, flexcluir, flconsultar) FROM stdin;
2	2	1	0	0	1
\.


--
-- Data for Name: tb_trans; Type: TABLE DATA; Schema: perfil; Owner: admin
--

COPY tb_trans (cdtrans, dstrans, flativa) FROM stdin;
2	Admin Sys	1
\.


--
-- Data for Name: tb_usuario; Type: TABLE DATA; Schema: perfil; Owner: admin
--

COPY tb_usuario (cpfusuario, cdperfil, nmusuario, pwdusuario, flativo) FROM stdin;
54343      	2	testando sistem	f1775e7cef50c7cc26845891831a0bf3	1
\.


SET default_tablespace = '';

--
-- Name: perfil_pk; Type: CONSTRAINT; Schema: perfil; Owner: admin; Tablespace: 
--

ALTER TABLE ONLY tb_perfil
    ADD CONSTRAINT perfil_pk PRIMARY KEY (cdperfil);


--
-- Name: perfil_trans_pk; Type: CONSTRAINT; Schema: perfil; Owner: admin; Tablespace: 
--

ALTER TABLE ONLY tb_perfil_trans
    ADD CONSTRAINT perfil_trans_pk PRIMARY KEY (cdperfil, cdtrans);


--
-- Name: trans_pk; Type: CONSTRAINT; Schema: perfil; Owner: admin; Tablespace: 
--

ALTER TABLE ONLY tb_trans
    ADD CONSTRAINT trans_pk PRIMARY KEY (cdtrans);


--
-- Name: usuario_pk; Type: CONSTRAINT; Schema: perfil; Owner: admin; Tablespace: 
--

ALTER TABLE ONLY tb_usuario
    ADD CONSTRAINT usuario_pk PRIMARY KEY (cpfusuario);


--
-- Name: tb_perfil_tb_perfil_trans_fk; Type: FK CONSTRAINT; Schema: perfil; Owner: admin
--

ALTER TABLE ONLY tb_perfil_trans
    ADD CONSTRAINT tb_perfil_tb_perfil_trans_fk FOREIGN KEY (cdperfil) REFERENCES tb_perfil(cdperfil);


--
-- Name: tb_perfil_tb_usuario_fk; Type: FK CONSTRAINT; Schema: perfil; Owner: admin
--

ALTER TABLE ONLY tb_usuario
    ADD CONSTRAINT tb_perfil_tb_usuario_fk FOREIGN KEY (cdperfil) REFERENCES tb_perfil(cdperfil);


--
-- Name: tb_trans_tb_perfil_trans_fk; Type: FK CONSTRAINT; Schema: perfil; Owner: admin
--

ALTER TABLE ONLY tb_perfil_trans
    ADD CONSTRAINT tb_trans_tb_perfil_trans_fk FOREIGN KEY (cdtrans) REFERENCES tb_trans(cdtrans);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

